/* Dock Companion — motor de sprites em pixel art.
 * Cada personagem é montado a partir de partes desenhadas como texto (1 caractere = 1 pixel,
 * só o preenchimento). O contorno é gerado automaticamente em volta de cada parte, e as cores
 * vêm da configuração escolhida no criador. Tudo é desenhado numa grade 36x36 e centralizado
 * num canvas 40x40, olhando para a direita (a esquerda é o espelho).
 */
(function (global) {
  'use strict';

  const N = 40, OX = 2, OY = 4;
  const OUTLINE = '#160f1c';

  // ---------- cores ----------
  const hex2rgb = (h) => { h = h.replace('#', ''); return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)); };
  const rgb2hex = (c) => '#' + c.map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
  const mix = (a, b, t) => { const A = hex2rgb(a), B = hex2rgb(b); return rgb2hex(A.map((v, i) => v + (B[i] - v) * t)); };
  const luma = (h) => { const [r, g, b] = hex2rgb(h); return (0.299 * r + 0.587 * g + 0.114 * b) / 255; };
  const pack = (h) => { const [r, g, b] = hex2rgb(h); return ((255 << 24) | (b << 16) | (g << 8) | r) >>> 0; };

  // ---------- pixmap ----------
  class Pix {
    constructor(w, h) { this.w = w; this.h = h; this.d = new Uint32Array(w * h); }
    get(x, y) { return x >= 0 && y >= 0 && x < this.w && y < this.h ? this.d[y * this.w + x] : 0; }
    set(x, y, v) { if (v && x >= 0 && y >= 0 && x < this.w && y < this.h) this.d[y * this.w + x] = v; }
  }
  const fromRows = (rows, pal) => {
    const w = Math.max(...rows.map((r) => r.length));
    const p = new Pix(w, rows.length);
    rows.forEach((r, y) => { for (let x = 0; x < r.length; x++) { const v = pal[r[x]]; if (v) p.set(x, y, v); } });
    return p;
  };
  const blit = (dst, src, ox, oy) => {
    for (let y = 0; y < src.h; y++) for (let x = 0; x < src.w; x++) {
      const v = src.d[y * src.w + x]; if (v) dst.set(ox + x, oy + y, v);
    }
  };
  const outline = (p) => {
    const o = new Pix(p.w, p.h); o.d.set(p.d); const k = pack(OUTLINE);
    for (let y = 0; y < p.h; y++) for (let x = 0; x < p.w; x++) {
      if (!p.get(x, y) && (p.get(x - 1, y) || p.get(x + 1, y) || p.get(x, y - 1) || p.get(x, y + 1))) o.set(x, y, k);
    }
    return o;
  };
  const flipH = (p) => { const o = new Pix(p.w, p.h); for (let y = 0; y < p.h; y++) for (let x = 0; x < p.w; x++) o.set(p.w - 1 - x, y, p.get(x, y)); return o; };
  const flipVrows = (rows) => rows.slice().reverse();
  const flipHrows = (rows) => { const w = Math.max(...rows.map((r) => r.length)); return rows.map((r) => r.padEnd(w, '.').split('').reverse().join('')); };
  const recolor = (rows, from, to) => rows.map((r) => r.split(from).join(to));

  /** Desenha uma nova camada (com contorno próprio) e a aplica no canvas. */
  const layer = (canvas, draw) => { const p = new Pix(N, N); draw(p); blit(canvas, outline(p), 0, 0); };
  const put = (p, rows, pal, x, y) => blit(p, fromRows(rows, pal), x + OX, y + OY);

  /** Linha grossa (pincel 2x2) em coordenadas da grade 36. */
  const stroke = (p, x0, y0, x1, y1, colorAt, brush = 2) => {
    const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) || 1;
    for (let i = 0; i <= n; i++) {
      const x = Math.round(x0 + ((x1 - x0) * i) / n), y = Math.round(y0 + ((y1 - y0) * i) / n);
      const c = colorAt(i, n);
      for (let a = 0; a < brush; a++) for (let b = 0; b < brush; b++) p.set(x + a + OX, y + b + OY, c);
    }
  };
  const polyline = (p, pts, colorAt) => {
    let idx = 0;
    for (let i = 0; i < pts.length - 1; i++) {
      const [x0, y0] = pts[i], [x1, y1] = pts[i + 1];
      stroke(p, x0, y0, x1, y1, (k) => colorAt(idx + k));
      idx += Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
    }
  };

  // =====================================================================
  //  QUADRÚPEDES (cachorro e gato)
  // =====================================================================
  const Q = {
    torsoLong: [
      '............bbbb....',
      '...........bbbbfb...',
      '..........bbbbfbbb..',
      '.hhhhhhhhhbbbfbbbbb.',
      'hHHhhhhhhbbbfbbbbbbr',
      'bbbbbbbbfbbbbbbfbbrr',
      'bbbfbbbfbbbbbbfbbrrr',
      'dbfbbbfbbbbbbfbbbrrr',
      'ddbbbfbbbbbbfbbbrrrr',
      'dddbdbdbdbdbdbdbrrr.',
      '.dd.d.d.d.d.d.d.rr.r',
      '..d.d...d...d...r...',
    ],
    torsoShort: [
      '............bbbb....',
      '...........bbbbfb...',
      '..........bbbbfbbb..',
      '.hhhhhhhhhbbbfbbbbb.',
      'hHHhhhhhhbbbfbbbbbbr',
      'bbbbbbbbfbbbbbbfbbrr',
      'bbbfbbbfbbbbbbfbbrrr',
      'dbfbbbfbbbbbbfbbbrrr',
      '.dbbbfbbbbbbfbbbrrr.',
      '..dddddddddddddrr...',
    ],
    torsoCat: [
      '.............bbb....',
      '............bbbbb...',
      '...........bbbbbbb..',
      '.hhhhhhhhhhbbbbbbb..',
      'hHHhhhhhhhbbbbbbbbb.',
      'bbbbbbbbbbbbbbbbbbr.',
      'bbbbbbbbbbbbbbbbbrr.',
      'dbbbbbbbbbbbbbbbrrr.',
      '.ddbbbbbbbbbbbbrrr..',
    ],
    torsoLie: [
      '..............bbbb..',
      '.............bbbbfb.',
      '..hhhhhhhhhhbbbbfbbb',
      '.hHHhhhhhhbbbbbfbbbb',
      'hbbbbbbbfbbbbbfbbbbr',
      'bbbbbbbfbbbbbfbbbrrr',
      'dbbbbbfbbbbbfbbbbrr.',
      'dddbdbdbdbdbdbdbbr..',
    ],
    torsoSit: [
      '..........bbbb.',
      '.........bbbbfb',
      '........bbbbfbb',
      '........bbbfbbb',
      '.......hbbfbbbr',
      '......hHbbbbbrr',
      '.....hbbbbbfbrr',
      '....hbbbbbfbrrr',
      '...hbbbbbfbbrr.',
      '..hHbbbbfbbbbr.',
      '.hbbbbbfbbbbbrr',
      '.hbbbbfbbbbfb..',
      'hbbbbfbbbbfbb..',
      'bbbbbbbbbfbb...',
      'bbbbbbbbfbbb...',
      'dbbbbbbbbbbd...',
      '.ddddddddd.....',
    ],
    torsoBelly: [
      '..d.d...d...d...r...',
      '.dd.d.d.d.d.d.d.rr..',
      'ddbbbbfbbbbbbfbbrrr.',
      'bbbbbbbfbbbbbbfbbrr.',
      'bbbbbbbbfbbbbbbfbbbb',
      'hbbbbbbbbbbbbbbbbbbb',
      '.hhhhHHhhhhhhhhhhhh.',
    ],
    // Manchas (pintadas só onde já existe pelo)
    patchTorso: [
      '....................',
      '....................',
      '....................',
      '..qqq.........qq....',
      '.qqqqq.......qqqq...',
      '.qqqqq........qqq...',
      '..qqq......qq.......',
      '..........qqqq......',
      '...........qq.......',
      '....................',
      '....................',
      '....................',
    ],
    stripes: [
      '....................',
      '....................',
      '.............s......',
      '...s...s...s.s......',
      '...s...s...s..s.....',
      '..s...s...s...s.....',
      '..s...s...s.........',
      '.s...s...s..........',
      '....................',
    ],

    // Cabeças de cachorro: arredondada, olhinho com brilho, linguinha pra fora
    dogHead: [
      '...hhhh........',
      '..hHHhhhh......',
      '.hbbbbbbbb.....',
      'hbbbbbbbbbb....',
      'bbbbbbbbhhbb...',
      'bbbbbbbbkwbbbb.',
      'bbbbbbbbkkbbbbg',
      'bbbbbbbbbbbbbnn',
      '.bbbbbbbbbbkkk.',
      '..bbbbbbbbbtT..',
      '...bbbbbb..tT..',
      '...........tt..',
    ],
    dogHeadBlink: [
      '...hhhh........',
      '..hHHhhhh......',
      '.hbbbbbbbb.....',
      'hbbbbbbbbbb....',
      'bbbbbbbbbbbb...',
      'bbbbbbbbbbbbbb.',
      'bbbbbbbbkkbbbbg',
      'bbbbbbbbbbbbbnn',
      '.bbbbbbbbbbkkk.',
      '..bbbbbbbbbtT..',
      '...bbbbbb..tT..',
      '...........tt..',
    ],
    dogHeadHappy: [
      '...hhhh........',
      '..hHHhhhh......',
      '.hbbbbbbbb.....',
      'hbbbbbbbbbb....',
      'bbbbbbbbbbbb...',
      'bbbbbbbbkbkbbb.',
      'bbbbbbbbbbbbbbg',
      'bbbbbbbbbbbbbnn',
      '.bbbbbbbbbmmmm.',
      '..bbbbbbbbbtT..',
      '...bbbbbb..tT..',
      '...........tT..',
      '...........tt..',
    ],
    dogHeadBark: [
      '...hhhh........',
      '..hHHhhhh......',
      '.hbbbbbbbb.....',
      'hbbbbbbbbbb....',
      'bbbbbbbbhhbb...',
      'bbbbbbbbkwbbbb.',
      'bbbbbbbbkkbbbbg',
      'bbbbbbbbbbmmmnn',
      '.bbbbbbbbbmmm..',
      '..bbbbbbbbbbbb.',
      '...bbbbbb......',
    ],
    dogHeadSleep: [
      '...hhhh........',
      '..hHHhhhh......',
      '.hbbbbbbbb.....',
      'hbbbbbbbbbb....',
      'bbbbbbbbbbbb...',
      'bbbbbbbbbbbbbb.',
      'bbbbbbbbkkbbbbg',
      'bbbbbbbbbbbbbnn',
      '.bbbbbbbbbbkkk.',
      '..bbbbbbbbb....',
      '...bbbbbb......',
    ],
    earFloppyLong: [
      '.hd.', 'hddd', 'dfdd', 'dfdd', 'ddfd', 'ddfd', 'dfdd', 'dfdd', 'ddd.', 'd.d.',
    ],
    earFloppyShort: [
      '.hd.', 'hddd', 'dddd', 'dddd', 'dddd', 'ddd.', '.d..',
    ],
    earFlap: ['hdddd..', '.dfdddd', '..ddfdd', '...dd.d'],
    earUp: ['...hb', '..bbb', '..bib', '.bbib', '.bbbb', 'bbbbb'],

    // Rabos em pluma (pelo longo)
    tailPlume: {
      down: ['.....hbb', '....hbbb', '...bfbb.', '..bbfbd.', '.bbfbd..', '.bfbdd..', 'bbfdd...', 'bfddd...', 'bddd.d..', 'bdd.....', 'dd.d....', 'd.......'],
      mid: ['........hb', '....hbbbbb', '..bbfbbbb.', '.bbfbbdd..', 'bbddd.d...', 'd.d.......'],
      upA: ['hb.....', 'bbb....', 'bfbb...', 'dbfbb..', '.dbfbb.', 'd.dbbbb', '...dbbb', '....dbb', '.....bb', '.....bb'],
      upB: ['..hb..', '.bbb..', '.bfb..', 'dbbfb.', '.dbbb.', '..dfbb', '..dbbb', '...bbb', '....bb', '....bb'],
      floor: ['.........hbb', '......hbbbbb', '..bbbfbbbbb.', 'dddddddd.d..'],
    },
    tailCurl: ['.hbb.', 'bb.bb', 'b..bb', '.bbb.', '..bb.'],
    tailStub: ['hb.', 'bbb', '.bb'],

    // Gato
    catHead: [
      '..hhhhh.....',
      '.hHhhhhhh...',
      'bbbbbbbbbb..',
      'bbbbbbbbbbb.',
      'bbbbbbbyybbb',
      'bbbbbbbykbbi',
      'rbbbbbbbbbm.',
      '.rrbbbbbbb..',
      '..rrbbbb....',
    ],
    catHeadBlink: [
      '..hhhhh.....',
      '.hHhhhhhh...',
      'bbbbbbbbbb..',
      'bbbbbbbbbbb.',
      'bbbbbbbbbbbb',
      'bbbbbbbkkbbi',
      'rbbbbbbbbbm.',
      '.rrbbbbbbb..',
      '..rrbbbb....',
    ],
    catHeadHappy: [
      '..hhhhh.....',
      '.hHhhhhhh...',
      'bbbbbbbbbb..',
      'bbbbbbbbbbb.',
      'bbbbbbbkbkbb',
      'bbbbbbbbbbbi',
      'rbbbbbbbbmm.',
      '.rrbbbbbmm..',
      '..rrbbbb....',
    ],
    catHeadMeow: [
      '..hhhhh.....',
      '.hHhhhhhh...',
      'bbbbbbbbbb..',
      'bbbbbbbbbbb.',
      'bbbbbbbyybbb',
      'bbbbbbbykbbi',
      'rbbbbbbbbmm.',
      '.rrbbbbbmmm.',
      '..rrbbbbbb..',
    ],
    catEar: ['..b..', '.bbb.', '.bib.', 'bbbbb'],
  };

  // Rabo fino (cachorro de pelo curto e gato): polilinhas por estado
  const POLY = {
    dog: {
      down: [[8, 22], [6, 25], [5, 29], [5, 31]],
      mid: [[8, 22], [5, 21], [2, 20], [0, 19]],
      upA: [[8, 22], [6, 18], [4, 14], [3, 11]],
      upB: [[8, 22], [7, 18], [7, 14], [8, 11]],
      floor: [[11, 33], [6, 33], [1, 32]],
    },
    cat: {
      down: [[8, 21], [5, 18], [3, 14], [4, 11], [6, 10]],
      mid: [[8, 21], [5, 19], [3, 15], [3, 12], [5, 10]],
      upA: [[8, 21], [6, 16], [6, 12], [7, 9], [9, 8]],
      upB: [[8, 21], [7, 16], [8, 12], [10, 10], [12, 10]],
      floor: [[11, 33], [6, 33], [2, 32], [1, 29]],
    },
  };

  function quadPalette(c) {
    const F = c.fur;
    const dark = luma(F) < 0.35;
    const pal = {
      b: F,
      d: mix(F, '#0d0a12', dark ? 0.4 : 0.28),
      f: dark ? mix(F, '#ffffff', 0.1) : mix(F, '#000000', 0.1),
      h: mix(F, '#ffffff', dark ? 0.22 : 0.28),
      H: mix(F, '#ffffff', dark ? 0.42 : 0.55),
      r: c.chest || F,
      q: c.patch || F,
      s: mix(F, '#0d0a12', 0.45),        // listras
      k: OUTLINE, n: '#120c16', w: '#ffffff', g: '#a7a0b0',
      t: '#e8455e', T: '#b02a45', m: '#5e1828',
      i: mix(F, '#f08aa0', 0.6),
      y: c.eyes || '#8cc63f',
      c: c.collar || F, C: '#f2c14e',
    };
    const out = {}; for (const k in pal) out[k] = pack(pal[k]); return out;
  }

  // Pernas: linha de 2 px com pata para a frente, franja de pelo longo e "meias" opcionais.
  function drawLeg(p, L, pal, cfg) {
    const fill = L.far ? pal.d : pal.b;
    const sock = cfg.socks ? pal.r : fill;
    const [x0, y0] = L.top, [x1, y1] = L.bottom;
    if (y0 === y1) {
      for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) {
        const c = Math.abs(x - x1) <= 1 && cfg.socks ? sock : fill;
        p.set(x + OX, y0 + OY, c); p.set(x + OX, y0 - 1 + OY, c);
      }
      return;
    }
    const xAt = (y) => Math.round(x0 + ((x1 - x0) * (y - y0)) / (y1 - y0));
    for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) {
      const x = xAt(y), c = Math.abs(y - y1) <= 1 ? sock : fill;
      p.set(x + OX, y + OY, c); p.set(x + 1 + OX, y + OY, c);
    }
    if (cfg.longFur && L.feather && y1 - y0 >= 6) {
      if (L.feather === 'front') { for (let y = y0 + 2; y <= y1 - 3; y++) p.set(xAt(y) - 1 + OX, y + OY, pal.d); p.set(xAt(y1 - 3) - 2 + OX, y1 - 3 + OY, pal.d); }
      else { for (let y = y0 + 1; y <= y0 + 4; y++) p.set(xAt(y) - 1 + OX, y + OY, pal.d); p.set(xAt(y0 + 4) - 2 + OX, y0 + 4 + OY, pal.d); }
    }
    if (L.paw !== false) p.set(x1 + 2 + OX, y1 + OY, sock);
  }

  const stand4 = (dx = [0, 0, 0, 0], lifted = []) => {
    const tops = [[10, 25], [12, 25], [21, 25], [23, 25]];
    return tops.map((t, i) => ({ top: t, bottom: [t[0] + dx[i], lifted.includes(i) ? 32 : 34], far: i % 2 === 0, feather: i < 2 ? 'back' : 'front' }));
  };

  function quadPose(cfg, pose) {
    const cat = cfg.species === 'cat';
    const pal = quadPalette(cfg);
    const longFur = !cat && cfg.coat === 'long';
    const c2 = { socks: cfg.socks, longFur };

    // Especificação padrão (em pé)
    const s = {
      torso: cat ? Q.torsoCat : longFur ? Q.torsoLong : Q.torsoShort, torsoX: 8, torsoY: 18,
      head: cat ? Q.catHead : Q.dogHead, headX: cat ? 22 : 21, headY: cat ? 11 : 8, headFlip: false,
      tail: 'down', tailDY: 0, legs: stand4(), lift: 0, drop: 0, flap: false,
    };
    const H = (k) => Q[(cat ? 'catHead' : 'dogHead') + k];

    switch (pose) {
      case 'stand': break;
      case 'blink': s.head = H('Blink'); break;
      case 'happy': case 'wagA': s.head = H('Happy'); s.tail = 'upA'; break;
      case 'wagB': s.head = H('Happy'); s.tail = 'upB'; break;
      case 'walk1': s.legs = stand4([2, -2, -2, 2]); s.tail = 'mid'; break;
      case 'walk2': s.legs = stand4([0, 0, 0, 0], [1, 2]); s.tail = 'mid'; s.lift = 1; break;
      case 'walk3': s.legs = stand4([-2, 2, 2, -2]); s.tail = 'mid'; break;
      case 'walk4': s.legs = stand4([0, 0, 0, 0], [0, 3]); s.tail = 'mid'; s.lift = 1; break;
      case 'run1': case 'run3':
        s.legs = [{ top: [10, 25], bottom: [4, 32], far: true, feather: 'back' }, { top: [12, 25], bottom: [6, 33], feather: 'back' },
          { top: [21, 25], bottom: [27, 32], far: true, feather: 'front' }, { top: [23, 25], bottom: [29, 33], feather: 'front' }];
        s.tail = 'mid'; s.tailDY = -1; s.lift = 1; s.flap = true; if (pose === 'run3') s.head = H('Happy'); break;
      case 'run2': case 'run4':
        s.legs = [{ top: [10, 25], bottom: [15, 32], far: true }, { top: [12, 25], bottom: [17, 33] },
          { top: [21, 25], bottom: [17, 32], far: true }, { top: [23, 25], bottom: [19, 33] }];
        s.tail = 'mid'; s.tailDY = -1; s.lift = 2; s.flap = true; if (pose === 'run4') s.head = H('Happy'); break;
      case 'sniff1': case 'sniff2':
        s.headY = cat ? 22 : 21; s.head = cat ? Q.catHead : (pose === 'sniff1' ? Q.dogHead : Q.dogHeadSleep);
        s.tail = pose === 'sniff2' ? 'upB' : 'upA'; break;
      case 'bark': s.head = cat ? Q.catHeadMeow : Q.dogHeadBark; s.headY -= 1; s.tail = 'upA'; break;
      case 'lookBack': s.headFlip = true; s.headX = cat ? 11 : 12; break;
      case 'crouch': s.drop = 2; s.tail = 'mid'; break;
      case 'jump':
        s.legs = [{ top: [10, 25], bottom: [3, 29], far: true }, { top: [12, 25], bottom: [5, 30] },
          { top: [21, 25], bottom: [28, 28], far: true }, { top: [23, 25], bottom: [30, 29] }];
        s.head = H('Happy'); s.tail = 'upA'; s.flap = true; break;
      case 'sit': case 'sitBlink': case 'sitHappy': case 'scratch1': case 'scratch2': case 'groom1': case 'groom2':
        s.torso = Q.torsoSit; s.torsoX = 11; s.torsoY = 18;
        s.headX = cat ? 21 : 20; s.headY = cat ? 11 : 8; s.tail = 'floor';
        s.legs = [{ top: [22, 27], bottom: [22, 34], far: true, feather: 'front' }, { top: [24, 27], bottom: [24, 34], feather: 'front' },
          { top: [14, 34], bottom: [20, 34], paw: false }];
        if (pose === 'sitBlink') s.head = H('Blink');
        if (pose === 'sitHappy') s.head = H('Happy');
        if (pose === 'scratch1' || pose === 'scratch2') {
          s.head = H('Blink'); s.headY += 2;
          const up = pose === 'scratch1';
          s.legs[2] = { top: [15, 31], bottom: [up ? 23 : 22, up ? 22 : 25], paw: false };
        }
        if (pose === 'groom1' || pose === 'groom2') {
          s.head = H('Blink'); s.headY += 3; s.headX -= 1;
          const up = pose === 'groom1';
          s.legs[1] = { top: [24, 27], bottom: [up ? 27 : 26, up ? 22 : 24], feather: 'front' };
        }
        break;
      case 'lie': case 'lieBlink': case 'sleep':
        s.torso = Q.torsoLie; s.torsoX = 7; s.torsoY = 27; s.tail = 'floor';
        s.legs = cat ? [] : [{ top: [22, 33], bottom: [31, 33], far: true, paw: false }, { top: [21, 34], bottom: [30, 34], paw: false }];
        if (cat) s.legs = [{ top: [21, 34], bottom: [27, 34], paw: false }];
        s.headX = cat ? 21 : 20; s.headY = cat ? 19 : 16;
        if (pose === 'lieBlink') s.head = H('Blink');
        if (pose === 'sleep') { s.head = cat ? Q.catHeadBlink : Q.dogHeadSleep; s.headX += 1; s.headY = cat ? 25 : 23; }
        break;
      case 'bow':
        s.legs = [{ top: [10, 22], bottom: [10, 34], far: true, feather: 'back' }, { top: [12, 22], bottom: [12, 34], feather: 'back' },
          { top: [22, 33], bottom: [31, 33], far: true, paw: false }, { top: [21, 34], bottom: [30, 34], paw: false }];
        s.torsoY = 17; s.headX = cat ? 21 : 20; s.headY = cat ? 24 : 21; s.head = H('Happy'); s.tail = 'upA'; s.tailDY = -4; break;
      case 'belly1': case 'belly2': {
        const a = pose === 'belly1' ? 0 : 1;
        s.torso = Q.torsoBelly; s.torsoX = 7; s.torsoY = 28; s.tail = 'floor';
        s.legs = [{ top: [10, 29], bottom: [8 + a, 22], far: true, paw: false }, { top: [13, 29], bottom: [12 - a, 22], paw: false },
          { top: [20, 29], bottom: [19 + a, 22], far: true, paw: false }, { top: [23, 29], bottom: [24 - a, 22], paw: false }];
        s.head = flipVrows(H('Happy')); s.headX = 21; s.headY = cat ? 26 : 22; s.bellyUp = true;
        break;
      }
      default: break;
    }

    const canvas = new Pix(N, N);
    const lift = s.lift, drop = s.drop;
    const sh = (L) => ({ ...L, top: [L.top[0], L.top[1] - lift + drop], bottom: [L.bottom[0], L.bottom[1] - lift] });

    // pernas (longe → perto)
    for (const L of s.legs.filter((l) => l.far)) layer(canvas, (p) => drawLeg(p, sh(L), pal, c2));
    for (const L of s.legs.filter((l) => !l.far)) layer(canvas, (p) => drawLeg(p, sh(L), pal, c2));

    // rabo
    const ty = -lift + drop + s.tailDY;
    const tailType = cat ? 'poly' : cfg.tail;
    layer(canvas, (p) => {
      if (tailType === 'plume') {
        const pos = { down: [1, 21], mid: [0, 19], upA: [2, 12], upB: [5, 12], floor: [0, 31] }[s.tail];
        put(p, Q.tailPlume[s.tail], pal, pos[0], pos[1] + (s.tail === 'floor' ? 0 : ty));
      } else if (tailType === 'curl') {
        const pos = s.tail === 'floor' ? [9, 25] : [4 + (s.tail === 'upB' ? 1 : 0), 16 + ty];
        put(p, Q.tailCurl, pal, pos[0], pos[1]);
      } else if (tailType === 'stub') {
        const pos = s.tail === 'floor' ? [9, 31] : s.tail === 'down' ? [6, 21 + ty] : [5 + (s.tail === 'upB' ? 1 : 0), 19 + ty];
        put(p, Q.tailStub, pal, pos[0], pos[1]);
      } else {
        const pts = (cat ? POLY.cat : POLY.dog)[s.tail].map(([x, y]) => [x, s.tail === 'floor' ? y : y + ty]);
        const striped = cat && cfg.pattern === 'tabby';
        polyline(p, pts, (i) => (striped && Math.floor(i / 2) % 2 ? pal.s : pal.b));
      }
    });

    // tronco (+ manchas / listras pintadas só onde há pelo)
    layer(canvas, (p) => {
      const tp = new Pix(N, N);
      put(tp, s.torso, pal, s.torsoX, s.torsoY - lift + drop);
      const paint = (rows) => {
        const m = new Pix(N, N); put(m, rows, pal, s.torsoX, s.torsoY - lift + drop);
        for (let i = 0; i < tp.d.length; i++) if (tp.d[i] && m.d[i] && tp.d[i] !== pal.r) tp.d[i] = m.d[i];
      };
      const standing = s.torso === Q.torsoLong || s.torso === Q.torsoShort || s.torso === Q.torsoCat;
      if (standing && cfg.patches) paint(Q.patchTorso);
      if (standing && cat && cfg.pattern === 'tabby') paint(Q.stripes);
      blit(p, tp, 0, 0);
    });

    // coleira
    if (cfg.collar && !s.bellyUp) {
      layer(canvas, (p) => {
        const cx = s.headX + (cat ? -1 : 0), cy = s.headY + (cat ? 8 : 10) - lift + drop;
        if (!s.headFlip) put(p, ['....cc', '..cccc', 'cccc..', 'cC....'], pal, cx - 1, cy - 1);
      });
    }

    // orelhas atrás da cabeça (em pé / gato)
    const hy = s.headY - lift + drop;
    const headRows = s.headFlip ? flipHrows(s.head) : s.head;
    const hw = Math.max(...s.head.map((r) => r.length));
    const ex = (x, w) => (s.headFlip ? s.headX + hw - x - w : s.headX + x);
    if (!s.bellyUp) {
      if (cat) {
        layer(canvas, (p) => put(p, recolor(Q.catEar, 'b', 'd'), pal, ex(1, 5), hy - 3));
        layer(canvas, (p) => put(p, Q.catEar, pal, ex(5, 5), hy - 3));
      } else if (cfg.ears === 'up' && !s.flap) {
        const er = s.headFlip ? flipHrows(Q.earUp) : Q.earUp;
        layer(canvas, (p) => put(p, recolor(er, 'b', 'd'), pal, ex(1, 5), hy - 4));
        layer(canvas, (p) => put(p, er, pal, ex(4, 5), hy - 5));
      }
    }

    // cabeça
    layer(canvas, (p) => put(p, headRows, pal, s.headX, hy));

    // orelha caída por cima
    if (!cat && !s.bellyUp && (cfg.ears !== 'up' || s.flap)) {
      if (s.flap) layer(canvas, (p) => put(p, Q.earFlap, pal, s.headX - 2, hy + 1));
      else {
        const er0 = longFur ? Q.earFloppyLong : Q.earFloppyShort;
        const er = s.headFlip ? flipHrows(er0) : er0;
        const ew = Math.max(...er0.map((r) => r.length));
        layer(canvas, (p) => put(p, er, pal, ex(2, ew), hy + 3));
      }
    }
    if (!cat && s.bellyUp) layer(canvas, (p) => put(p, flipVrows(longFur ? Q.earFloppyLong : Q.earFloppyShort), pal, s.headX + 2, hy - 1));

    // bigodes do gato (sem contorno)
    if (cat && !s.bellyUp) {
      const wc = pack('#e9e4ee');
      const pts = s.headFlip ? [[-1, 5], [-2, 4], [-1, 7], [-2, 7]] : [[12, 5], [13, 4], [12, 7], [13, 7]];
      for (const [x, y] of pts) if (!canvas.get(s.headX + x + OX, hy + y + OY)) canvas.set(s.headX + x + OX, hy + y + OY, wc);
    }
    return canvas;
  }

  const QUAD_POSES = ['stand', 'blink', 'happy', 'wagA', 'wagB', 'walk1', 'walk2', 'walk3', 'walk4', 'run1', 'run2', 'run3', 'run4',
    'sniff1', 'sniff2', 'bark', 'lookBack', 'crouch', 'jump', 'sit', 'sitBlink', 'sitHappy', 'scratch1', 'scratch2', 'groom1', 'groom2',
    'lie', 'lieBlink', 'sleep', 'bow', 'belly1', 'belly2'];

  // =====================================================================
  //  PESSOA
  // =====================================================================
  const P = {
    head: [
      '....sssss.....',
      '..sssssssss...',
      '.sssssssssss..',
      'sssssssssssss.',
      'sssssssssssss.',
      'sssssssssnsss.',
      'ssSssssssnssss',
      'sSSssssssssss.',
      'ssSssssssssss.',
      'sssssssmmsss..',
      '.sssssssssss..',
      '..ssssssss....',
    ],
    hair: {
      short: { dx: 0, dy: -1, rows: [
        '....aaaaa.....',
        '..aaaaaaaaa...',
        '.aaaaAAaaaaa..',
        'aaaaaaaaaaaa..',
        'aaaaaaaaaaaa..',
        'aaaaa.aa.a....',
        'aa............',
      ] },
      spiky: { dx: 0, dy: -4, rows: [
        '..a..a..a.....',
        '.aa.aa.aa.a...',
        '.aaaaaaaaaaa..',
        'aaaaaaaaaaaaa.',
        'aaaaaAAaaaaa..',
        'aaaaaaaaaaaa..',
        'aaaaaaaaaaaa..',
        'aaaa.aa.a.a...',
        'aa............',
      ] },
      curly: { dx: -2, dy: -4, rows: [
        '....aaaaaaa......',
        '..aaaaaaaaaaa....',
        '.aaaaaAAaaaaaa...',
        'aaaaaaaaaaaaaaa..',
        'aaaaaaaaaaaaaaa..',
        'aaaaaaaaaaaaaaa..',
        'aaaaaaaaaaaaaa...',
        'aaaaaaa.a.a.a....',
        'aaaaa............',
        'aaaa.............',
        '.aa..............',
      ] },
      long: { dx: -1, dy: -1, rows: [
        '.....aaaaa.....',
        '...aaaaaaaaa...',
        '..aaaaaAAaaaa..',
        '.aaaaaaaaaaaa..',
        '.aaaaaaaaaaaa..',
        'aaaaaa.aaa.a...',
        'aaaa...........',
        'aaaa...........',
        'aaaa...........',
        'aaaa...........',
        'aaaa...........',
        'aaaa...........',
        'aaaa...........',
        '.aaa...........',
        '..a............',
      ] },
      bun: { dx: -1, dy: -4, rows: [
        '..aaa..........',
        '.aaaaa.........',
        '.aaaaa.........',
        '..aaaaaaaa.....',
        '..aaaaAAaaaa...',
        '.aaaaaaaaaaaa..',
        '.aaaaaaaaaaaa..',
        '.aaaaaaaaaa....',
        '.aaa...........',
      ] },
      bob: { dx: -1, dy: -1, rows: [
        '.....aaaaa.....',
        '...aaaaaaaaa...',
        '..aaaaaAAaaaa..',
        '.aaaaaaaaaaaaa.',
        '.aaaaaaaaaaaaa.',
        '.aaaaaaaaa.....',
        'aaaaa..........',
        'aaaaa..........',
        'aaaaa..........',
        'aaaa...........',
        '.aa............',
      ] },
      buzz: { dx: 0, dy: 0, rows: [
        '....AAAAA.....',
        '..AAAAAAAAA...',
        '.AAAAAAAAAA...',
        'AAAAAAAAAA....',
        'AAA...........',
      ] },
      bald: null,
    },
    cap: { dx: -1, dy: -2, rows: [
      '....zzzzzz......',
      '..zzzzzzzzzz....',
      '.zzzzZzzzzzzz...',
      '.zzzzzzzzzzzzzzz',
    ] },
    beanie: { dx: -1, dy: -3, rows: [
      '.....zzz......',
      '...zzzzzzz....',
      '..zzzzzzzzzz..',
      '.zzzzzzzzzzzz.',
      '.ZZZZZZZZZZZZ.',
      '.ZZZZZZZZZZZZ.',
    ] },
  };

  function personPalette(c) {
    const skin = c.skin, hair = c.hairColor;
    const pal = {
      s: skin, S: mix(skin, '#5a2a1a', 0.22),
      a: hair, A: mix(hair, '#ffffff', luma(hair) < 0.3 ? 0.18 : 0.25),
      B: mix(skin, hair, 0.28),
      n: '#1a1220', m: '#6e2b33', w: '#ffffff', k: OUTLINE,
      e: c.shirt, E: mix(c.shirt, '#0d0a12', 0.3),
      p: c.pants, P: mix(c.pants, '#0d0a12', 0.3),
      o: c.shoes, O: mix(c.shoes, '#0d0a12', 0.3),
      z: c.hatColor || '#d23b3b', Z: mix(c.hatColor || '#d23b3b', '#0d0a12', 0.25),
      l: c.glasses === 'round' ? '#c9a24a' : '#1a1220', L: '#c6dcef',
    };
    const out = {}; for (const k in pal) out[k] = pack(pal[k]); return out;
  }

  function personHeadRows(cfg, face) {
    let rows = P.head.slice();
    const setc = (x, y, ch) => { rows[y] = rows[y].slice(0, x) + ch + rows[y].slice(x + 1); };
    if (face === 'blink') { setc(9, 5, 's'); setc(9, 6, 'n'); }
    if (face === 'happy') { setc(9, 6, 's'); setc(8, 6, 'n'); setc(9, 5, 'n'); setc(10, 6, 'n'); for (const x of [7, 8, 9, 10]) setc(x, 9, 'm'); setc(8, 10, 'm'); setc(9, 10, 'm'); }
    if (face === 'oh') { setc(7, 9, 's'); setc(8, 9, 'm'); setc(9, 9, 'm'); setc(8, 10, 'm'); setc(9, 10, 'm'); }
    if (cfg.beard === 'stubble') for (const [x, y] of [[4, 10], [6, 11], [8, 11], [10, 10], [9, 8], [11, 8], [5, 9], [3, 9]]) if (rows[y][x] === 's') setc(x, y, 'B');
    if (cfg.beard === 'full') for (let y = 8; y <= 11; y++) for (let x = 2; x <= 12; x++) if (rows[y][x] === 's' && !(y === 9 && (x === 7 || x === 8))) setc(x, y, 'a');
    if (cfg.beard === 'mustache') for (let x = 7; x <= 10; x++) setc(x, 8, 'a');
    return rows;
  }

  function personPose(cfg, pose) {
    const pal = personPalette(cfg);
    const canvas = new Pix(N, N);
    const pants = cfg.pantsType === 'pants';

    const s = {
      headX: 11, headY: 8, face: 'normal', headFlip: false, torsoY: 20, lift: 0,
      legs: [{ hip: [15, 29], foot: [15, 34], far: true }, { hip: [18, 29], foot: [18, 34] }],
      arms: [{ sh: [14, 21], hand: [14, 27], far: true }, { sh: [19, 21], hand: [19, 27] }],
      sit: false,
    };
    const L = (fdx, ndx, lf = [], ln = []) => [
      { hip: [15, 29], foot: [15 + fdx, lf.length ? 32 : 34], far: true },
      { hip: [18, 29], foot: [18 + ndx, ln.length ? 32 : 34] },
    ];
    const A = (fdx, ndx, fy = 27, ny = 27) => [{ sh: [14, 21], hand: [14 + fdx, fy], far: true }, { sh: [19, 21], hand: [19 + ndx, ny] }];

    switch (pose) {
      case 'stand': break;
      case 'blink': s.face = 'blink'; break;
      case 'happy': case 'wagA': case 'wagB': s.face = 'happy'; break;
      case 'walk1': s.legs = L(-2, 2); s.arms = A(2, -2); break;
      case 'walk2': s.legs = L(0, 0, [1]); s.lift = 1; break;
      case 'walk3': s.legs = L(2, -2); s.arms = A(-2, 2); break;
      case 'walk4': s.legs = L(0, 0, [], [1]); s.lift = 1; break;
      case 'run1': case 'run3': s.legs = L(-4, 4); s.arms = A(4, -4, 25, 25); s.headX += 1; s.lift = 1; if (pose === 'run3') s.face = 'happy'; break;
      case 'run2': case 'run4': s.legs = L(1, -1, [1], [1]); s.arms = A(-3, 3, 25, 25); s.headX += 1; s.lift = 2; if (pose === 'run4') s.face = 'happy'; break;
      case 'jump': s.face = 'happy'; s.legs = [{ hip: [15, 29], foot: [13, 32], far: true }, { hip: [18, 29], foot: [20, 32] }];
        s.arms = [{ sh: [14, 21], hand: [10, 14], far: true }, { sh: [19, 21], hand: [23, 14] }]; break;
      case 'surprised': case 'bark': s.face = 'oh'; s.arms = [{ sh: [14, 21], hand: [10, 15], far: true }, { sh: [19, 21], hand: [23, 15] }]; break;
      case 'crouch': s.lift = -2; s.legs = [{ hip: [15, 31], foot: [14, 34], far: true }, { hip: [18, 31], foot: [19, 34] }]; break;
      case 'lookBack': s.headFlip = true; s.headX = 10; break;
      case 'wave1': case 'wave2': s.face = 'happy'; s.arms = [{ sh: [14, 21], hand: [14, 27], far: true }, { sh: [19, 21], hand: pose === 'wave1' ? [23, 13] : [21, 12] }]; break;
      case 'sit': case 'sitBlink': case 'sitHappy': case 'sleep':
        s.sit = true; s.headY = 13; s.torsoY = 25;
        s.face = pose === 'sitBlink' || pose === 'sleep' ? 'blink' : pose === 'sitHappy' ? 'happy' : 'normal';
        if (pose === 'sleep') s.headY = 14;
        s.arms = [{ sh: [14, 26], hand: [17, 31], far: true }, { sh: [19, 26], hand: [22, 31] }];
        break;
      default: break;
    }

    const lift = s.lift;
    const shirtLen = 3; // manga curta

    // braço de trás
    const drawArm = (a) => layer(canvas, (p) => {
      const sh = [a.sh[0], a.sh[1] - lift], hd = [a.hand[0], a.hand[1] - lift];
      stroke(p, sh[0], sh[1], hd[0], hd[1], (i) => (i < shirtLen ? (a.far ? pal.E : pal.e) : a.far ? pal.S : pal.s));
    });
    const drawLegP = (l) => layer(canvas, (p) => {
      const hip = [l.hip[0], l.hip[1] - lift], ft = [l.foot[0], l.foot[1] - (l.foot[1] < 34 ? lift : 0)];
      if (s.sit) return;
      stroke(p, hip[0], hip[1], ft[0], ft[1] - 1, (i) => (pants || i < 1 ? (l.far ? pal.P : pal.p) : l.far ? pal.S : pal.s));
      const sc = l.far ? pal.O : pal.o;
      for (let x = 0; x <= 3; x++) p.set(ft[0] + x + OX, ft[1] + OY, sc);
      for (let x = 0; x <= 2; x++) p.set(ft[0] + x + OX, ft[1] - 1 + OY, sc);
    });

    s.legs.filter((l) => l.far).forEach(drawLegP);
    s.arms.filter((a) => a.far).forEach(drawArm);
    s.legs.filter((l) => !l.far).forEach(drawLegP);

    // pernas sentado: esticadas para a frente sobre o Dock
    if (s.sit) {
      layer(canvas, (p) => {
        for (let x = 17; x <= 25; x++) { const c = pants || x < 19 ? pal.p : pal.s; p.set(x + OX, 33 + OY, c); p.set(x + OX, 34 + OY, c); }
        for (let y = 30; y <= 34; y++) { p.set(26 + OX, y + OY, pal.o); p.set(27 + OX, y + OY, pal.o); }
      });
    }

    // tronco
    layer(canvas, (p) => {
      const ty = s.torsoY - lift;
      put(p, [
        '.eeeeeeee.',
        'eeeeeeeeee',
        'eeeeeeeeee',
        'eeeeeeeeee',
        'eeeeeeeeee',
        'EEEEEEEEEE',
        'pppppppppp',
        'pppppppppp',
        s.sit ? 'pppppppppp' : 'ppppp.pppp',
      ], pal, 13, ty);
    });

    // braço da frente
    s.arms.filter((a) => !a.far).forEach(drawArm);

    // cabeça + cabelo + chapéu
    const hx = s.headX, hy = s.headY - lift;
    const head = personHeadRows(cfg, s.face);
    const hr = s.headFlip ? flipHrows(head) : head;
    layer(canvas, (p) => put(p, hr, pal, hx, hy));
    const hair = P.hair[cfg.hair];
    const hw = 14;
    if (hair) {
      const rows = s.headFlip ? flipHrows(hair.rows) : hair.rows;
      const w = Math.max(...hair.rows.map((r) => r.length));
      const x = s.headFlip ? hx + hw - hair.dx - w : hx + hair.dx;
      layer(canvas, (p) => put(p, rows, pal, x, hy + hair.dy));
    }
    if (cfg.hat === 'cap' || cfg.hat === 'beanie') {
      const h = P[cfg.hat];
      const rows = s.headFlip ? flipHrows(h.rows) : h.rows;
      const w = Math.max(...h.rows.map((r) => r.length));
      const x = s.headFlip ? hx + hw - h.dx - w : hx + h.dx;
      layer(canvas, (p) => put(p, rows, pal, x, hy + h.dy));
    }

    // óculos (arame fino, sem contorno)
    if (cfg.glasses && cfg.glasses !== 'none' && !s.headFlip) {
      const ex = hx + 9, ey = hy + 5; // olho
      const set = (x, y, c) => canvas.set(x + OX, y + OY, c);
      const ring = cfg.glasses === 'square'
        ? [[-2, -1], [-1, -1], [0, -1], [1, -1], [2, -1], [-2, 0], [2, 0], [-2, 1], [2, 1], [-2, 2], [-1, 2], [0, 2], [1, 2], [2, 2]]
        : [[-1, -1], [0, -1], [1, -1], [-2, 0], [2, 0], [-2, 1], [2, 1], [-1, 2], [0, 2], [1, 2]];
      if (cfg.glasses === 'sun') for (const [x, y] of [[-1, 0], [0, 0], [1, 0], [-1, 1], [0, 1], [1, 1]]) set(ex + x, ey + y, pal.n);
      for (const [x, y] of ring) set(ex + x, ey + y, pal.l);
      for (const [x, y] of [[-3, 0], [-4, 0], [-5, 0], [-6, 1], [3, 0], [4, 0]]) set(ex + x, ey + y, pal.l);
    }
    return canvas;
  }

  const PERSON_POSES = ['stand', 'blink', 'happy', 'walk1', 'walk2', 'walk3', 'walk4', 'run1', 'run2', 'run3', 'run4',
    'jump', 'surprised', 'crouch', 'lookBack', 'wave1', 'wave2', 'sit', 'sitBlink', 'sitHappy', 'sleep'];

  // =====================================================================
  //  Efeitos (balões)
  // =====================================================================
  const FX = {
    heart: ['.kk.kk.', 'kRRkRRk', 'kRRRRRk', 'kRRRRRk', '.kRRRk.', '..kRk..', '...k...'],
    bang: ['.kkkkk.', 'kWWkWWk', 'kWWkWWk', 'kWWkWWk', 'kWWWWWk', 'kWWkWWk', '.kkkkk.', '..kk...', '..k....'],
    zzz: ['..........', '.....kkkk.', '.....kWWk.', '......kk..', '.....kWWk.', 'kkk..kkkk.', 'kWk.......', 'kkk.......'],
    au: ['.kkkkkkkkkkk.', 'kWWWWWWWWWWWk', 'kWWkkWWkWWkWk', 'kWkWWkWkWWkWk', 'kWkkkkWkWWkWk', 'kWkWWkWkWWkWk', 'kWkWWkWWkkWWk', 'kWWWWWWWWWWWk', '.kkkkkkkkkkk.', '..kk.........', '..k..........'],
    dust1: ['..zz....zz..', '.zzZz..zZzz.', '..zz....zz..'],
    dust2: ['z..........z', '.z.z....z.z.', '..z......z..'],
    question: ['.kkkkkk.', 'kWkkkkWk', 'kWWWWkWk', 'kWWWkWWk', 'kWWWWWWk', 'kWWWkWWk', '.kkkkkk.', '..kk....', '..k.....'],
    note: ['...kkk', '...kWk', '...k.k', '...k..', '.kkk..', 'kWWk..', '.kk...'],
  };
  const FXPAL = { k: pack(OUTLINE), R: pack('#e8455e'), W: pack('#fbf8f2'), z: pack('#d8d2c4'), Z: pack('#a8a090') };

  // =====================================================================
  //  API
  // =====================================================================
  function toCanvas(p) {
    const c = document.createElement('canvas'); c.width = p.w; c.height = p.h;
    const ctx = c.getContext('2d'); const img = ctx.createImageData(p.w, p.h);
    new Uint32Array(img.data.buffer).set(p.d); ctx.putImageData(img, 0, 0); return c;
  }
  function bounds(p) {
    let x0 = p.w, x1 = -1;
    for (let y = 0; y < p.h; y++) for (let x = 0; x < p.w; x++) if (p.d[y * p.w + x]) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); }
    let y0 = p.h, y1 = -1;
    for (let y = 0; y < p.h; y++) for (let x = 0; x < p.w; x++) if (p.d[y * p.w + x]) { y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
    return { x0, x1, y0, y1 };
  }

  /** Gera todos os quadros de um personagem: { right, left, bounds, poses }. */
  function buildCharacter(cfg) {
    const poses = cfg.species === 'person' ? PERSON_POSES : QUAD_POSES;
    const make = cfg.species === 'person' ? personPose : quadPose;
    const right = {}, left = {}, bx = {};
    for (const pose of poses) {
      const p = make(cfg, pose);
      right[pose] = toCanvas(p); left[pose] = toCanvas(flipH(p)); bx[pose] = bounds(p);
    }
    return { right, left, bounds: bx, poses, size: N, center: N / 2 };
  }
  const fx = {};
  function effect(name) { if (!fx[name]) fx[name] = toCanvas(fromRows(FX[name], FXPAL)); return fx[name]; }

  /** Opções do criador (site) → configuração do motor. Usado pelo site e pelo app de Mac. */
  function makerToSprite(species, c) {
    if (species === 'person') return { species, ...c };
    if (species === 'dog') {
      return { species, fur: c.fur, coat: c.coat, ears: c.ears, tail: c.tail, chest: c.chest === 'same' ? c.fur : c.chest,
        patches: c.patches === 'yes', patch: c.patch, collar: c.collar === 'none' ? null : c.collar };
    }
    const pat = c.pattern;
    return { species, fur: c.fur, pattern: pat === 'tabby' ? 'tabby' : 'solid', eyes: c.eyes,
      chest: pat === 'white' || pat === 'tuxedo' ? '#f4f1ea' : pat === 'tabby' ? '#f6dcb8' : c.fur,
      socks: pat === 'white' || pat === 'tuxedo', collar: c.collar === 'none' ? null : c.collar };
  }

  /** Quadros como números (sem canvas): { size, poses, frames: { pose: [rgba...] } }. */
  function buildRawFromMaker(species, makerCfg) {
    const cfg = makerToSprite(species, makerCfg);
    const poses = cfg.species === 'person' ? PERSON_POSES : QUAD_POSES;
    const make = cfg.species === 'person' ? personPose : quadPose;
    const frames = {};
    for (const pose of poses) frames[pose] = Array.from(make(cfg, pose).d);
    return { size: N, poses, frames };
  }
  function effectRaw(name) {
    const p = fromRows(FX[name], FXPAL);
    return { w: p.w, h: p.h, data: Array.from(p.d) };
  }
  const EFFECTS = Object.keys(FX);

  global.DockSprites = { buildCharacter, effect, SIZE: N, makerToSprite, buildRawFromMaker, effectRaw, EFFECTS };
})(typeof window !== 'undefined' ? window : globalThis);
